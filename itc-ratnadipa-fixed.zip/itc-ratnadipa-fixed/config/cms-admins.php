<?php
// CMS administrator accounts. Managed from the CMS.
return array (
  0 => 
  array (
    'id' => 1,
    'name' => 'Bhasura',
    'email' => 'basurasandun@gmail.com',
    'password' => '$2y$10$t5olOGZ3NKYA6vgOQ0KH8.8Bx2z7FyALEdl8zCK5FHu2.fuigoV5.',
  ),
);
