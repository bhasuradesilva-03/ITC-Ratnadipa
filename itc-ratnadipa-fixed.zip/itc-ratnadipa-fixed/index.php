<?php
require_once __DIR__ . "/includes/data.php";
$pageTitle = 'ITC Ratnadipa | A Luxury Collection Hotel, Colombo';
$active = 'home';
$publicPage = true;
$withSplash = true; // intro screen, first visit per browser session
$stay = stay_from_request($_GET ?? []);
$CMS = $CMS ?? (require __DIR__ . '/includes/cms-content.php');
require_once 'includes/header.php';
require_once 'includes/navbar.php';

$highlights = array_map(fn($f) => [$f['icon'] ?? 'star', $f['title'] ?? 'Feature'], $CMS['features']);
?>
<main>
    <section class="hero" style="--cms-hero-image:url('assets/<?= strpos($CMS['hero']['image'] ?? '', 'uploads/') === 0 ? e($CMS['hero']['image']) : 'images/' . e($CMS['hero']['image'] ?? 'hero.jpg') ?>')">
        <div class="hero-content">
            <p class="kicker"><?= e($CMS['hero']['eyebrow']) ?></p>
            <h1><?= e($CMS['hero']['title']) ?></h1>
            <h2><?= e($CMS['hero']['subtitle']) ?></h2>
            <p class="hero-copy"><?= e($CMS['hero']['description']) ?></p>
            <a class="btn btn-gold" href="<?= e($CMS['hero']['button_url']) ?>"><?= e($CMS['hero']['button_text']) ?></a>
        </div>
    </section>

    <div class="search-wrap">
        <?php include 'includes/search-form.php'; ?>
    </div>

    <section class="section" id="rooms">
        <header class="section-head">
            <p class="kicker">Our Rooms &amp; Suites</p>
            <h2>Elegant Stays, Unforgettable Views</h2>
            <p>Choose from our beautifully appointed rooms and suites, each designed for your comfort with stunning views of the ocean, city or Beira Lake.</p>
        </header>
        <div class="room-grid">
            <?php foreach ($ROOMS as $room): ?>
                <?php include 'includes/room-card.php'; ?>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="section" id="restaurant">
        <header class="section-head"><p class="kicker">Restaurant</p><h2><?= e($CMS['restaurant']['title']) ?></h2><p><?= e($CMS['restaurant']['description']) ?></p></header>
        <div class="package-grid">
            <?php foreach ($CMS['restaurant']['items'] as $item): ?>
                <article class="package-card"><div class="card-media"><img src="assets/<?= strpos($item['image'] ?? '', 'uploads/') === 0 ? e($item['image']) : 'images/' . e($item['image'] ?? 'full-board.jpg') ?>" alt="<?= e($item['name']) ?>" loading="lazy"></div><div class="package-body"><h3><?= e($item['name']) ?></h3><p><?= e($item['description']) ?></p></div></article>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="section" id="offers"><header class="section-head"><p class="kicker">Special Offers</p><h2>Offers &amp; Privileges</h2></header><div class="package-grid">
    <?php foreach ($CMS['offers'] as $offer): if (empty($offer['active'])) continue; ?>
      <article class="package-card"><div class="package-body"><h3><?= e($offer['title']) ?></h3><p><?= e($offer['description']) ?></p><p><strong><?= e($offer['discount']) ?> off</strong> · Promo code: <strong><?= e($offer['code']) ?></strong></p><small>Valid until <?= e($offer['valid_until']) ?></small></div></article>
    <?php endforeach; ?></div></section>

    <section class="section" id="reviews"><header class="section-head"><p class="kicker">Guest Experiences</p><h2>Guest Reviews</h2></header><div class="package-grid">
    <?php foreach ($CMS['reviews'] as $review): if (empty($review['approved'])) continue; ?>
      <article class="package-card"><div class="package-body"><p><?= e($review['message']) ?></p><p aria-label="Rating"><?= str_repeat('★', max(1,min(5,(int)$review['rating']))) ?></p><strong><?= e($review['name']) ?></strong></div></article>
    <?php endforeach; ?></div></section>

    <section class="section" id="packages">
        <header class="section-head">
            <p class="kicker">Hotel Packages</p>
            <h2>More Ways to Experience ITC Ratnadipa</h2>
        </header>
        <div class="package-grid">
            <?php foreach ($PACKAGES as $pkg): ?>
                <?php include 'includes/package-card.php'; ?>
            <?php endforeach; ?>
        </div>
    </section>

    <section class="section" id="features"><header class="section-head"><p class="kicker">The Experience</p><h2>Discover ITC Ratnadipa</h2></header><div class="package-grid"><?php foreach($CMS['features'] as $feature): ?><article class="package-card"><div class="package-body"><h3><?= e($feature['title']) ?></h3><p><?= e($feature['description']) ?></p></div></article><?php endforeach; ?></div></section>

    <section class="highlights" id="highlights" aria-label="Hotel highlights">
        <ul>
            <?php foreach ($highlights as [$ico, $label]): ?>
                <li><?= icon($ico) ?><span><?= e($label) ?></span></li>
            <?php endforeach; ?>
        </ul>
    </section>
</main>
<?php require_once 'includes/footer.php'; ?>
